<?php

$user=strtolower($_POST["Login"]);
$senha=strtolower($_POST["Senha"]);
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "enade";


// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
//echo "Connected successfully";

$sql = "SELECT n_aluno, s_aluno FROM aluno";
$result = $conn->query($sql);

  while($row = $result->fetch_assoc()) {
         
         if ($user == $row["n_aluno"] and $senha == $row["s_aluno"]){

         	header("location: /casos de teste/videos/movie.html");	
         }
         else{

         	echo "<script>alert('LOGIN OU SENHA INCORRETA!');";
			echo "javascript:window.location='aluno.html';</script>";
         }

    }

 
$conn->close();



?>	