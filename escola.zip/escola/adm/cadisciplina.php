<?php

$dcp=$_POST["disc"];
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "enade";


// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
//echo "Connected successfully";



		$sql = "INSERT INTO disciplina (id_disc,disc)
VALUES ('','$dcp')";

if ($conn->query($sql) === TRUE) {
    echo "<script>alert('CADASTRADO COM SUCESSO!');";
	echo "javascript:window.location='cad.html';</script>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}






 
$conn->close();



?>	