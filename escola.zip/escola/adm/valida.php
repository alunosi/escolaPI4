<?php

$user=strtolower($_POST["Login"]);
$senha=strtolower($_POST["Senha"]);
$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "enade";


// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
//echo "Connected successfully";

$sql = "SELECT login, senha FROM adm";
$result = $conn->query($sql);

    while($row = $result->fetch_assoc()) {
         
         if ($user == $row["login"] and $senha == $row["senha"]){	

         	header("location: cad.html");	
         }
         else{
			echo "<script>alert('LOGIN OU SENHA INCORRETA!');";
			echo "javascript:window.location='admin.html';</script>";       	    
         }

    }

 
$conn->close();



?>	