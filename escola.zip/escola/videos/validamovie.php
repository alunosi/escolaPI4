<?php

$servername = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "enade";


// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
//echo "Connected successfully";
    
$sql = "SELECT video,descricao FROM arquivos";
$result = $conn->query($sql);

    while($row = $result->fetch_assoc()) {
         
         echo $row["video"];
         header("Content-Type:.mp4");
         echo $row["descricao"]; 	

    }

    
$conn->close();



?>	