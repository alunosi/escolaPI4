use enade;
select login,senha from adm;
insert into adm value(1,"enade","123");
delete from adm where id=1;

create table aluno (
id_aluno int primary key,
n_aluno varchar(100),
s_aluno varchar(10)
);

create table professor(
    id_prof int primary key,
	n_prof varchar(100)
);

ALTER TABLE arquivos add column descricao varchar(200);

create table disciplina(
	id_disc int primary key,
	disc varchar(100)
);

create table arquivos (

	id_aqr int primary key,
    video blob

);

select * from professor;	
delete from disciplina where id_disc=1;
truncate table adm;


